export enum SystemOrQueuing {
  System = 'system',
  Queuing = 'queuing',
}

export enum TypeCalculate {
  Fixed = 'fixed',
  Max = 'max',
  AtLeast = 'least',
}

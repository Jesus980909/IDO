import React from 'react';

const NotFoundPage = () => {
  return <div>page not found 404</div>;
};

export default NotFoundPage;

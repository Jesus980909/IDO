import React from 'react'

const About = () => {
    return (
        <div>
            about page
        </div>
    )
}

export default About

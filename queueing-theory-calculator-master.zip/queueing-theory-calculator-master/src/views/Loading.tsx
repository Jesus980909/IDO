import React from 'react';

const Loading = () => {
  return <div>loading page...</div>;
};

export default Loading;
